#!/sbin/sh

# List of the driver files
package_list="
Thermals"

ui_print " ";
 ui_print ""
  ui_print ""
ui_print "   ╭━╮╭━╮╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╭╮"
ui_print "   ╰╮╰╯╭╯╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱┃┃"
ui_print "   ╱╰╮╭╯╭━━┳━╮╭━━┳╮╭┳━━┳━╯┣━━╮"
ui_print "   ╱╭╯╰╮┃┃━┫╭╮┫╭╮┃╰╯┃╭╮┃╭╮┃━━┫"
ui_print "   ╭╯╭╮╰┫┃━┫┃┃┃╰╯┃┃┃┃╰╯┃╰╯┣━━┃"
ui_print "   ╰━╯╰━┻━━┻╯╰┻━━┻┻┻┻━━┻━━┻━━╯"
  ui_print "                             Gaming XM-THERMALS   "
  ui_print ""
  ui_print ""
ui_print "                                               ";   
ui_print " ";
ui_print "*******************************************************";
ui_print " Developed by XenoOP - @XenoMods / @XenoModDiscuss   ";
ui_print "*******************************************************";
sleep 1.5
ui_print "📱Processor : $(getprop ro.product.board) "
ui_print " "
sleep 0.5
ui_print "📱Arm Version : $(getprop ro.product.cpu.abi) "
ui_print " "
sleep 0.5
ui_print "📱Board Platform : $(getprop ro.board.platform) "
ui_print " "
sleep 0.5
ui_print "📱Manufacturer : $(getprop ro.product.system.manufacturer) "
ui_print " "


ui_print " "

for g in $package_list; do
    ui_print "- Installing $g";
    tar -xf "$MODPATH/XenoMods/$g.tar.xz" -C $MODPATH;
    rm -f $MODPATH/XenoMods/$g.tar.xz
    rm -rf $MODPATH/XenoMods
done;
