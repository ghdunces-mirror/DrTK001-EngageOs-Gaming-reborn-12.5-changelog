
set_permissions() {
  set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  set_perm_recursive "$MODPATH/system/bin" root root 0777 0755
  set_perm_recursive $MODPATH/system/lib64 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/bin 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/bin/hw 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/etc/init 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/lib 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/lib/hw 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/lib64 0 0 0755 0644
  set_perm_recursive $MODPATH/system/vendor/lib64/hw 0 0 0755 0644
}

sh "$MODPATH/system/bin/XenoTweaks" &> /dev/null

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh
