#!/sbin/sh

# Import Fstab
. /tmp/anykernel/tools/fstab.sh;

# Import Remover
. /tmp/anykernel/tools/remover.sh;

patch_cmdline "skip_override" "";

sdriver=1
install_td=""
install_cpu=""
install_dhz=""
install_tm=""
install_ac=""

#Check D8G DIR
if [ ! -d /data/media/0/d8g ]; then
	mkdir -p /data/media/0/d8g;
fi
if [ ! -d /data/media/0/d8g/pubg ]; then
	mkdir -p /data/media/0/d8g/pubg;
fi

# Clear
ui_print "";
ui_print "";

keytest() {
  ui_print "   Press a Vol Key..."
  (/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > /tmp/anykernel/events) || return 1
  return 0
}

chooseport() {
  #note from chainfire @xda-developers: getevent behaves weird when piped, and busybox grep likes that even less than toolbox/toybox grep
  while (true); do
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > /tmp/anykernel/events
    if (`cat /tmp/anykernel/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
      break
    fi
  done
  if (`cat /tmp/anykernel/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
    return 0
  else
    return 1
  fi
}

chooseportold() {
  # Calling it first time detects previous input. Calling it second time will do what we want
  $bin/keycheck
  $bin/keycheck
  SEL=$?
  if [ "$1" == "UP" ]; then
    UP=$SEL
  elif [ "$1" == "DOWN" ]; then
    DOWN=$SEL
  elif [ $SEL -eq $UP ]; then
    return 0
  elif [ $SEL -eq $DOWN ]; then
    return 1
  else
    abort "   Vol key not detected!"
  fi
}

if keytest; then
  FUNCTION=chooseport
else
  FUNCTION=chooseportold
  ui_print "   Press Vol Up Again..."
  $FUNCTION "UP"
  ui_print "   Press Vol Down..."
  $FUNCTION "DOWN"
fi

# Install Kernel

# Clear
ui_print " ";
ui_print " ";

# Choose Img
ui_print " "
ui_print "Choose Driver Touchscreen ?"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Install Latest Touchscreen"
ui_print "   No!!... Install Old Touchscreen"
ui_print " "
if $FUNCTION; then
	ui_print "-> New Touchscreen Selected.."
	install_td="  -> Installing New Touchscreen..."
	sdriver=1
else
	ui_print " "
	ui_print "Choose Driver Touchscreen ?"
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Install Old Touchscreen"
	ui_print "   No!!... Install Touchscreen Pie"
	ui_print " "
	if $FUNCTION; then
		ui_print "-> Old Touchscreen Selected.."
		install_td="  -> Installing Old Touchscreen..."
		sdriver=0
	else
		ui_print "-> Latest Touchscreen Pie Selected.."
		install_td="  -> Installing Latest Touchscreen Pie..."
		sdriver=2
	fi
fi

# Choose CPU
ui_print " "
ui_print "Choose Overclock CPU ?"
ui_print "   Vol+ = Yes, Vol- = No"
ui_print "   Yes!!... Install CPU Max 2.9 GHz"
ui_print "   No!!... Install CPU Max 2.8 GHz"
ui_print " "
if $FUNCTION; then
	ui_print "-> OC CPU Selected.."
	install_cpu="  -> OC CPU..."
	if [ $sdriver =  0 ]; then
		decompressed_image=$home/kernel/oc/o/Image
	else
		if [ $sdriver =  1 ]; then
			decompressed_image=$home/kernel/oc/n/Image
		else
			decompressed_image=$home/kernel/oc/p/Image
		fi
	fi
	compressed_image=$decompressed_image.gz
else
	ui_print "-> Stock CPU Selected.."
	install_cpu="  -> Stock CPU..."
	if [ $sdriver =  0 ]; then
		decompressed_image=$home/kernel/noc/o/Image
	else
		if [ $sdriver =  1 ]; then
			decompressed_image=$home/kernel/noc/n/Image
		else
			decompressed_image=$home/kernel/noc/p/Image
		fi
	fi
	compressed_image=$decompressed_image.gz
fi

# Choose dts
ui_print " "
ui_print "Choose your favorite display hz?"
ui_print " "
ui_print "Jangan dipaksa, gunakan semampu device kalian"
ui_print " "
ui_print "   Vol+ = Yes, Vol- = No"
ui_print ""
ui_print "   Yes!!... Install FPS 60hz"
ui_print "   No!!... Choose again"
ui_print " "

if $FUNCTION; then
	ui_print "-> Display 60hz Selected.."
	install_dhz="  -> Display 60hz...";
	if [ -f $compressed_image ]; then
		# Concatenate all of the dtbs to the kernel
		cat $compressed_image $home/kernel/dtbs/60/*.dtb > $home/Image.gz-dtb;
	fi
else
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Install FPS 61hz"
	ui_print "   No!!... Choose again"
	ui_print " "
	if $FUNCTION; then
		# 61hz
		ui_print "-> Display 61hz Selected.."
		install_dhz="  -> Display 61hz...";
		if [ -f $compressed_image ]; then
			# Concatenate all of the dtbs to the kernel
			cat $compressed_image $home/kernel/dtbs/61/*.dtb > $home/Image.gz-dtb;
		fi
	else
		ui_print "   Vol+ = Yes, Vol- = No"
		ui_print "   Yes!!... Install FPS 65hz"
		ui_print "   No!!... Choose again"
		ui_print " "
		if $FUNCTION; then
			# 65hz
			ui_print "-> Display 65hz Selected.."
			install_dhz="  -> Display 65hz...";
			if [ -f $compressed_image ]; then
				# Concatenate all of the dtbs to the kernel
				cat $compressed_image $home/kernel/dtbs/65/*.dtb > $home/Image.gz-dtb;
			fi
		else
			ui_print "   Vol+ = Yes, Vol- = No"
			ui_print "   Yes!!... Install FPS 66hz"
			ui_print "   No!!... Choose again"
			ui_print " "
			if $FUNCTION; then
				# 66hz
				ui_print "-> Display 66hz Selected.."
				install_dhz="  -> Display 66hz...";
				if [ -f $compressed_image ]; then
					# Concatenate all of the dtbs to the kernel
					cat $compressed_image $home/kernel/dtbs/66/*.dtb > $home/Image.gz-dtb;
				fi
			else
				ui_print "   Vol+ = Yes, Vol- = No"
				ui_print "   Yes!!... Install FPS 67hz"
				ui_print "   No!!... Choose again"
				ui_print " "
				if $FUNCTION; then
					# 67hz
					ui_print "-> Display 67hz Selected.."
					install_dhz="  -> Display 67hz...";
					if [ -f $compressed_image ]; then
						# Concatenate all of the dtbs to the kernel
						cat $compressed_image $home/kernel/dtbs/67/*.dtb > $home/Image.gz-dtb;
					fi
				else
					ui_print "   Vol+ = Yes, Vol- = No"
					ui_print "   Yes!!... Install FPS 68hz"
					ui_print "   No!!... Choose again"
					ui_print " "
					if $FUNCTION; then
						# 68hz
						ui_print "-> Display 68hz Selected.."
						install_dhz="  -> Display 68hz...";
						if [ -f $compressed_image ]; then
							# Concatenate all of the dtbs to the kernel
							cat $compressed_image $home/kernel/dtbs/68/*.dtb > $home/Image.gz-dtb;
						fi
					else
						ui_print "   Vol+ = Yes, Vol- = No"
						ui_print "   Yes!!... Install FPS 69hz"
						ui_print "   No!!... Choose again"
						ui_print " "
						if $FUNCTION; then
							# 69hz
							ui_print "-> Display 69hz Selected.."
							install_dhz="  -> Display 69hz...";
							if [ -f $compressed_image ]; then
								# Concatenate all of the dtbs to the kernel
								cat $compressed_image $home/kernel/dtbs/69/*.dtb > $home/Image.gz-dtb;
							fi
						else
							ui_print "   Vol+ = Yes, Vol- = No"
							ui_print "   Yes!!... Install FPS 70hz"
							ui_print "   No!!... Choose again"
							ui_print " "
							if $FUNCTION; then
								# 70hz
								ui_print "-> Display 70hz Selected.."
								install_dhz="  -> Display 70hz...";
								if [ -f $compressed_image ]; then
									# Concatenate all of the dtbs to the kernel
									cat $compressed_image $home/kernel/dtbs/70/*.dtb > $home/Image.gz-dtb;
								fi
							else
								ui_print "   Vol+ = Yes, Vol- = No"
								ui_print "   Yes!!... Install FPS 71hz"
								ui_print "   No!!... Install Stock FPS - 60hz"
								ui_print " "
								if $FUNCTION; then
									# 71hz
									ui_print "-> Display 71hz Selected.."
									install_dhz="  -> Display 71hz...";
									if [ -f $compressed_image ]; then
										# Concatenate all of the dtbs to the kernel
										cat $compressed_image $home/kernel/dtbs/71/*.dtb > $home/Image.gz-dtb;
									fi
								else
									ui_print "-> Display 60hz Selected.."
									install_dhz="  -> Display 60hz...";
									if [ -f $compressed_image ]; then
										# Concatenate all of the dtbs to the kernel
										cat $compressed_image $home/kernel/dtbs/60/*.dtb > $home/Image.gz-dtb;
									fi
								fi
							fi
						fi
					fi
				fi
			fi
		fi
	fi
fi

# Choose Permissive or Enforcing
ui_print " "
ui_print "Choose Default Selinux to Install.."
ui_print " "
ui_print "Permissive Or Enforcing Kernel?"
ui_print " "
ui_print "   Vol+ = Yes, Vol- = No"
ui_print ""
ui_print "   Yes.. Permissive"
ui_print "   No!!... Enforcing"
ui_print " "

if $FUNCTION; then
	ui_print "-> Permissive Kernel Selected.."
	install_pk="  -> Permissive Kernel..."
	patch_cmdline androidboot.selinux androidboot.selinux=permissive
else
	ui_print "-> Enforcing Kernel Selected.."
	install_pk="  -> Enforcing Kernel..."
	patch_cmdline androidboot.selinux androidboot.selinux=enforcing
fi

# Choose Thermal
if [ -d /data/adb/modules/d8g_thermal ]; then
	ui_print " "
	ui_print "D8G Thermal Installed. Update ?"
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Update D8G Thermal"
	ui_print "   No!!... Choose another options"
	ui_print " "
	if $FUNCTION; then
		ui_print "-> Update D8G Thermal Selected.."
		rm -fr /data/adb/modules/d8g_thermal;
		install_tms=" "
		install_tm="  -> Updating D8G Thermal..."
		echo "Thermal Config" >> /data/media/0/d8g/rm_tmb
		#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tmb
	else
		ui_print " "
		ui_print "Install Balance Thermal ?"
		ui_print "   Vol+ = Yes, Vol- = No"
		ui_print "   Yes!!... Install Balance Thermal"
		ui_print "   No!!... Skip Update D8G Thermal"
		ui_print " "
		if $FUNCTION; then
			ui_print "-> Install Balance Thermal Selected.."
			rm -fr /data/adb/modules/d8g_thermal;
			install_tms=" "
			install_tm="  -> Installing Balance Thermal..."
			echo "Thermal Config" >> /data/media/0/d8g/rm_tm
			#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tm
		else
			ui_print "-> Skip Update Thermal Selected.."
			install_tms=" "
			install_tm="  -> Skip Update Thermal..."
			echo "Thermal Config" >> /data/media/0/d8g/rm_tm
			echo "Thermal Config" >> /data/media/0/d8g/rm_tmb
			#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tm
			#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tmb
		fi
	fi
else
	if [ -d /data/adb/modules/d8g_thermal_balance ]; then
		ui_print " "
		ui_print "Balance Thermal Installed. Update ?"
		ui_print "   Vol+ = Yes, Vol- = No"
		ui_print "   Yes!!... Update Balance Thermal"
		ui_print "   No!!... Choose another options"
		ui_print " "
		if $FUNCTION; then
			ui_print "-> Update Balance Thermal Selected.."
			rm -fr /data/adb/modules/d8g_thermal_balance;
			install_tms=" "
			install_tm="  -> Updating Balance Thermal..."
			echo "Thermal Config" >> /data/media/0/d8g/rm_tm
			#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tm
		else
			ui_print " "
			ui_print "Install D8G Thermal ?"
			ui_print "   Vol+ = Yes, Vol- = No"
			ui_print "   Yes!!... Install D8G Thermal"
			ui_print "   No!!... Skip Update Balance Thermal"
			ui_print " "
			if $FUNCTION; then
				ui_print "-> Install D8G Thermal Selected.."
				rm -fr /data/adb/modules/d8g_thermal_balance;
				install_tms=" "
				install_tm="  -> Installing D8G Thermal..."
				echo "Thermal Config" >> /data/media/0/d8g/rm_tmb
				#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tmb
			else
				ui_print "-> Skip Update D8G Thermal.."
				install_tms=" "
				install_tm="  -> Skip Update Thermal..."
				echo "Thermal Config" >> /data/media/0/d8g/rm_tm
				echo "Thermal Config" >> /data/media/0/d8g/rm_tmb
				#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tm
				#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tmb
			fi
		fi
	else
		ui_print " "
		ui_print "Install D8G Thermal ?"
		ui_print "   Vol+ = Yes, Vol- = No"
		ui_print "   Yes!!... Install D8G Thermal"
		ui_print "   No!!... Choose another options"
		ui_print " "
		if $FUNCTION; then
			ui_print "-> Install D8G Thermal.."
			install_tms=" "
			install_tm="  -> Installing D8G Thermal..."
			echo "Thermal Config" >> /data/media/0/d8g/rm_tmb
			#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tmb
		else
			ui_print " "
			ui_print "Install Balance Thermal ?"
			ui_print "   Vol+ = Yes, Vol- = No"
			ui_print "   Yes!!... Install Balance Thermal"
			ui_print "   No!!... Not Install Thermal"
			ui_print " "
			if $FUNCTION; then
				ui_print "-> Install Balance Thermal.."
				install_tms=" "
				install_tm="  -> Installing Balance Thermal..."
				echo "Thermal Config" >> /data/media/0/d8g/rm_tm
				#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tm
			else
				ui_print "-> Skip Install D8G Thermal.."
				install_tms=""
				install_tm="  -> Skip Install D8G Thermal..."
				echo "Thermal Config" >> /data/media/0/d8g/rm_tm
				echo "Thermal Config" >> /data/media/0/d8g/rm_tmb
				#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tm
				#cp $home/kernel/module/rm_tm /data/media/0/d8g/rm_tmb
			fi
		fi
	fi
fi

# Choose Amoled Color
if [ -d /data/adb/modules/d8g_amoled ]; then
	ui_print " "
	ui_print "D8G Amoled Color Installed. Update ?"
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Update D8G Amoled Color"
	ui_print "   No!!... Skip Update D8G Amoled Color"
	ui_print " "
	if $FUNCTION; then
		ui_print "-> Update D8G Amoled Color Selected.."
		rm -fr /data/adb/modules/d8g_amoled;
		install_acs=" "
		install_ac="  -> Updating D8G Amoled Color..."
	else
		ui_print "-> Skip Update D8G Amoled Color Selected.."
		install_acs=" "
		install_ac="  -> Skip Update Amoled Color..."
	fi
else
	ui_print " "
	ui_print "Install D8G Amoled Color ?"
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Install Amoled Color"
	ui_print "   No!!... Not Install Amoled Color"
	ui_print " "
	if $FUNCTION; then
		ui_print "-> Install D8G Amoled Color.."
		install_acs=" "
		install_ac="  -> Installing D8G Amoled Color..."
	else
		ui_print "-> Skip Install D8G Amoled Color.."
		echo "Amoled Color Config" >> /data/media/0/d8g/rm_ac
		#cp $home/kernel/module/rm_ac /data/media/0/d8g/rm_ac
		install_acs=""
		install_ac="  -> Skip Install D8G Amoled Color..."
	fi
fi

#TouchX
if [ -d /data/adb/modules/d8g_touchi ]; then
	ui_print " "
	ui_print "Touch Improvements Installed. Update ?"
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Update Touch Improvements"
	ui_print "   No!!... Skip Update Touch Improvements"
	ui_print " "
	if $FUNCTION; then
		rm -fr /data/adb/modules/d8g_touchi;
		ui_print "-> Update TouchX Selected.."
		install_tis=" "
		install_ti="  -> Updating TouchX..."
	else
		ui_print "-> Skip Update TouchX Selected.."
		install_tis=" "
		install_ti="  -> Skip Update TouchX..."
	fi
else
	ui_print " "
	ui_print "Install TouchX ?"
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print "   Yes!!... Install TouchX"
	ui_print "   No!!... Not Install TouchX"
	ui_print " "
	if $FUNCTION; then
		ui_print "-> Install TouchX Selected.."
		install_tis=" "
		install_ti="  -> Installing TouchX..."
	else
		ui_print "-> Skip Install TouchX.."
		install_tis=""
		install_ti="  -> Skip Install TouchX..."
		echo "TouchX Config" >> /data/media/0/d8g/rm_ti
		#cp $home/kernel/module/rm_ti /data/media/0/d8g/rm_ti
	fi
fi

# Choose Permissive or Enforcing
ui_print " "
ui_print "PUBG User..??"
ui_print " "
ui_print "Select your option"
ui_print " "
ui_print "   Vol+ = Yes, Vol- = No"
ui_print ""
ui_print "   Yes.. PUBG Users"
ui_print "   No!!... Not Playing PUBG"
ui_print " "

if $FUNCTION; then
	# Max FPS
	ui_print " "
	ui_print "Install Default Patch Max FPS.."
	ui_print " "
	ui_print "   PUBG Can be Patch to Max FPS"
	ui_print "   with select install on this option"
	ui_print "   or you can edit manually your Active.sav"
	ui_print " "
	ui_print "   Edit Active.sav on sdcard/d8g/pubg/ori/Active.sav"
	ui_print "   if you don't know how to edit it you can search "
	ui_print "   on google unlock 90 fps and copy your edited to "
	ui_print "   sdcard/d8g/pubg/Active.sav"
	ui_print " "
	ui_print "   This patch will be reset to default settings"
	ui_print "   if you change settings graphics on pubg."
	ui_print "   you can get it back with Start PUBG HDR Extreme"
	ui_print "   (Qstile - featured from DKM)"
	ui_print " "
	ui_print "   You can lock this patch, but it's not recomended"
	ui_print "   maybe you can get banned, but i don't know"
	ui_print "   to enable change value sdcard/d8g/pubg/ro to 1"
	ui_print "   to disbale change value to 0"
	ui_print " "
	ui_print "   Vol+ = Yes, Vol- = No"
	ui_print " "
	ui_print "   Yes.. Use Default Patch Max FPS"
	ui_print "   No!!... don't patch Max FPS by default"
	ui_print " "

	if $FUNCTION; then
		ui_print "-> Try patch max FPS by default config.."
		install_ppubg="  -> Try patch max FPS by default..."
		echo "1" >> /data/media/0/d8g/pubg/dp
	else
		ui_print "-> Not use patch max FPS by default.."
		install_ppubg="  -> Not use patch max FPS - edit manually..."
		echo "0" >> /data/media/0/d8g/pubg/dp
	fi
else
	ui_print "-> Not Playing PUBG.."
	install_ppubg="  -> Skip Max FPS Patch..."
	echo "0" >> /data/media/0/d8g/pubg/dp
fi

ui_print " "
ui_print "Installing D8G Kernel with :"
ui_print "$install_td"
ui_print "$install_cpu"
ui_print "$install_dhz"
ui_print "$install_pk"
ui_print " "
ui_print "Module and Patch Options :"
ui_print "$install_tm"
ui_print "$install_ac"
ui_print "$install_ti"
ui_print "$install_ppubg"
