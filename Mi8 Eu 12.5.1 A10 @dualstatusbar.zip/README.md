#magisk
 Don't share direct zip ,if want to share with your
 friends then share the link only..
 
 Thanks :)